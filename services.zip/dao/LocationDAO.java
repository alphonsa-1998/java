package com.deloitte.demo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.deloitte.demo.model.Location;


@Repository

public class LocationDAO {

	public static Connection connectToDB() {
		Connection connection = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "admin");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;

	}

	public ArrayList<Location> displayUser() {
		ArrayList<Location> userList = new ArrayList<Location>();
		try {
			Connection con = connectToDB();
			PreparedStatement stmt = con.prepareStatement("select * from location");
			
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				Location user = new Location();

				user.setRouteId(rs.getString(1));
				user.setFrom(rs.getString(2));
				user.setTo(rs.getString(3));
				user.setFromTime(rs.getString(4));
				user.setToTime(rs.getString(5));
				user.setStop1(rs.getString(6));
				user.setStop2(rs.getString(7));
				user.setStop3(rs.getString(8));
				user.setTime1(rs.getString(9));
				user.setTime2(rs.getString(10));
				user.setTime3(rs.getString(11));
				user.setTrainNo(rs.getString(12));
				userList.add(user);
			}
			// Step 5:Close Connection
			con.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return userList;

	}


	
	
	
	
	
	
	
	
	
	
	/*
	 * public void addUser(Location loc) { try {
	 * 
	 * Connection con = connectToDB(); PreparedStatement stmt =
	 * con.prepareStatement("insert into location values(?,?,?,?,?,?,?,?,?,?,?,?)");
	 * stmt.setString(1, loc.getRouteId()); stmt.setString(2, loc.getFrom());
	 * stmt.setString(3, loc.getTo()); stmt.setString(4, loc.getFromTime());
	 * stmt.setString(5, loc.getToTime()); stmt.setString(6, loc.getStop1());
	 * stmt.setString(7, loc.getStop2()); stmt.setString(8, loc.getStop3());
	 * stmt.setString(9, loc.getTime1()); stmt.setString(10, loc.getTime2());
	 * stmt.setString(11, loc.getTime3()); stmt.setString(12, loc.getTrainNo());
	 * 
	 * // Step 4: Execute SQL Query int affectedRows = stmt.executeUpdate();
	 * System.out.println("Affected rows " + affectedRows);
	 * 
	 * // Step 5:Close Connection con.close();
	 * 
	 * } catch (SQLException e) { // TODO Auto-generated catch block
	 * e.printStackTrace(); }
	 * 
	 * }
	 */

}
