package com.example.demo.services;


import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.UserDAO;
import com.example.demo.model.UserDetails;

@Service

public class UserService {

	@Autowired
	UserDAO dao;

	/*public ArrayList<UserDetails> getMessage() {
		return dao.displayUser();
	}*/

	
	public ArrayList<UserDetails> getMessage() {
	
		return dao.displayUser();
	}

	public String getUserId() {
		// TODO Auto-generated method stub
		return getUserId();
	}
	public String getName() {
		// TODO Auto-generated method stub
		return getName();
	}
	public String getEmail() {
		// TODO Auto-generated method stub
		return getEmail();
	}
	public String getPhone() {
		// TODO Auto-generated method stub
		return getPhone();
	}
	
	/*public void add(UserDetails user)
	{
		dao.addUser(user);
	}*/
}




/*public class UserService {

}
}*/