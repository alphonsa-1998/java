package com.example.demo.controller;
//import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.UserDetails;
//import com.example.demo.services.LibraryService;
import com.example.demo.services.UserService;

@Controller
@ResponseBody
public class UserController{

	@Autowired
	UserService service;
	
	@PostMapping("/user")
	public ModelAndView myMethod(@RequestBody UserDetails user) {
		ModelAndView modelandview = new ModelAndView();
		modelandview.setViewName("welcome");
		//modelandview.addObject("user",service.getUserId());
		return modelandview;
	}
	
	/*@GetMapping("/user")
	public ModelAndView location(@RequestParam("userId") String userId,@RequestParam("name") String name,@RequestParam("phone") int phone,@RequestParam("email") String email) {
		ModelAndView loc = new ModelAndView();
		loc.setViewName("AdminLocation");
		return loc;
	}
	*/
	
		

	/*@RequestMapping("/user")
	public ArrayList<UserDetails> getMessage(@RequestParam("userId") String uId) {
		return service.getMessage();
	}*/
	
	
	/*@RequestMapping("/adduser")
	public void addUser(@RequestParam("userId") String uId,@RequestParam("name") String name,@RequestParam("password") String pwd,@RequestParam("phone") int phone,@RequestParam("email") String email) 
	{
		//return service.getMessage();
	
	UserDetails user=new UserDetails();
	user.setName(name);
	user.setUserId(uId);
	user.setPassword(pwd);
	user.setPhone(phone);
	user.setEmail(email);
	
	service.add(user);
	}
	

	@GetMapping("/")
	public String getmap() {
		return "hello";
	}
	
	
	@PostMapping("/adduse")
	public void addUser(@RequestBody UserDetails user)
	{
		//return service.getMessage();
	
	System.out.println(user);
	service.add(user);
	}
	*/
	
	@RequestMapping("/")
	public String getUser() {
		return "user details will be displayed";
	}

}


